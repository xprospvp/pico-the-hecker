import sys
import subprocess
import pkg_resources

required = {'PyQt5', 'PyQtWebEngine'}
installed = {pkg.key for pkg in pkg_resources.working_set}
missing = required - installed

if missing:
    python = sys.executable
    subprocess.check_call([python, '-m', 'pip', 'install', *missing], stdout=subprocess.DEVNULL)

from PyQt5.QtCore import QUrl
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import QApplication

app = QApplication(sys.argv)

web = QWebEngineView()
web.load(QUrl("https://www.youtube.com/watch?v=dQw4w9WgXcQ"))
web.show()

sys.exit(app.exec_())